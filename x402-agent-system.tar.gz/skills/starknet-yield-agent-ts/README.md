# 🦞 Starknet Yield Agent

x402-compatible API for Starknet DeFi yields and analytics.

Based on [langoustine69's](https://langoustine69.github.io) x402 agent pattern.

## Monetization

| Endpoint | Price | Revenue/1K calls |
|----------|-------|------------------|
| `/api/market-summary` | FREE | $0 |
| `/api/top-yields` | $0.001 | $10 |
| `/api/protocol-details` | $0.002 | $20 |
| `/api/rwa-opportunities` | $0.003 | $30 |
| `/api/yield-compare` | $0.002 | $20 |
| `/api/risk-analysis` | $0.005 | $50 |

**Estimated revenue:** $100-1000/month depending on traffic

## Quick Start

```bash
# Install Bun (required)
curl -fsSL https://bun.sh/install | bash

# Install dependencies
bun install

# Run locally
bun run dev

# Build for production
bun run build
```

## Deploy to Vercel

```bash
# Deploy automatically
vercel --prod

# Or connect GitHub repo at https://vercel.com
```

## Environment Variables

```env
PAYMENTS_RECEIVABLE_ADDRESS=0x0C3D21e8835990427405F6FeA649f1fb8CB30ED6
```

## API Usage

### FREE: Market Summary
```bash
curl https://your-agent.vercel.app/api/market-summary
```

### PAID: Top Yields
```bash
curl -H "X-Payment-Proof: <x402-proof>" \
  https://your-agent.vercel.app/api/top-yields?limit=10
```

## Project Structure

```
starknet-yield-agent/
├── package.json
├── tsconfig.json
├── vercel.json
├── README.md
└── src/
    ├── index.ts           # Main agent
    └── data/
        └── yields.json    # Pool data
```

## Powered By

- [Lucid Agents SDK](https://github.com/langoustine69/lucid-agents)
- [x402 Protocol](https://x402.org)
- TypeScript + Bun
- Vercel
