#!/bin/bash
# x402 Agents Production Deployment Script
# Usage: ./deploy.sh [yield|ct|all]

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}🚀 x402 Agent Deployment Script${NC}"
echo "=================================="

# Check prerequisites
check_prereqs() {
    echo -e "${YELLOW}Checking prerequisites...${NC}"
    
    if ! command -v npm &> /dev/null; then
        echo -e "${RED}Error: npm not found. Install Node.js first.${NC}"
        exit 1
    fi
    
    if ! command -v vercel &> /dev/null; then
        echo -e "${YELLOW}Installing Vercel CLI...${NC}"
        npm i -g vercel
    fi
    
    echo -e "${GREEN}✓ Prerequisites OK${NC}"
}

# Deploy yield agent
deploy_yield() {
    echo -e "${YELLOW}Deploying Starknet Yield Agent...${NC}"
    cd skills/starknet-yield-agent-ts
    
    echo "Installing dependencies..."
    npm install
    
    echo "Deploying to Vercel..."
    vercel --prod --yes
    
    echo -e "${GREEN}✓ Starknet Yield Agent deployed!${NC}"
    cd ../..
}

# Deploy CT agent
deploy_ct() {
    echo -e "${YELLOW}Deploying CT Intelligence Agent...${NC}"
    cd skills/ct-intelligence-agent-ts
    
    echo "Installing dependencies..."
    npm install
    
    echo "Deploying to Vercel..."
    vercel --prod --yes
    
    echo -e "${GREEN}✓ CT Intelligence Agent deployed!${NC}"
    cd ../..
}

# Main
check_prereqs

case "${1:-all}" in
    yield)
        deploy_yield
        ;;
    ct)
        deploy_ct
        ;;
    all)
        deploy_yield
        deploy_ct
        ;;
    *)
        echo "Usage: ./deploy.sh [yield|ct|all]"
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}✅ Deployment complete!${NC}"
echo ""
echo "Next steps:"
echo "1. Check Vercel dashboard for URLs"
echo "2. Test endpoints: curl <URL>/api/health"
echo "3. Update NETWORK to 'base' for mainnet"
echo "4. Promote on CT"
