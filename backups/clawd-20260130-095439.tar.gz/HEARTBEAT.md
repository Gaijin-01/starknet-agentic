# HEARTBEAT.md

Keep this file empty unless you want a tiny checklist. Keep it small.
