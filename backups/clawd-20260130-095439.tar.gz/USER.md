# USER.md - About Your Human

*Learn about the person you're helping. Update this as you go.*

- **Name:** Sefirot
- **What to call them:** Sefirot (or just "you" 😄)
- **Timezone:** Asia/Jerusalem (GMT+2)
- **Notes:**
  - Connected via Telegram on 2026-01-22
  - Goes by "Groove_Armada" on Telegram

## Context

*(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)*

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
