"""
Twitter API Skill - Native X/Twitter API integration.

Provides posting, replying, quoting, and analytics capabilities
using Twitter API v2.
"""

__version__ = "1.0.0"
__author__ = "Evolver"
